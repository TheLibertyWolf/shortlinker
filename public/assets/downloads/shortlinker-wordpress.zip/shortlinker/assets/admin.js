(() => {
  "use strict";
  const request = async (action, values = {}) => {
    const data = new URLSearchParams({ action, ...values });
    const response = await fetch(ShortlinkerAdmin.ajaxUrl, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data,
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error((result.data && result.data.message) || ShortlinkerAdmin.error);
    return result.data;
  };
  const copyText = async (value) => {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(value);
    const input = document.createElement("textarea");
    input.value = value;
    input.style.position = "fixed";
    input.style.opacity = "0";
    document.body.appendChild(input);
    input.select();
    const copied = document.execCommand("copy");
    input.remove();
    if (!copied) throw new Error(ShortlinkerAdmin.copyError);
  };
  const renderShortlink = (container, url, linkId) => {
    const row = document.createElement("div");
    row.className = "shortlinker-url-row";
    const link = document.createElement("a");
    link.className = "shortlinker-url";
    link.href = url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = url;
    const copy = document.createElement("button");
    copy.type = "button";
    copy.className = "button button-small shortlinker-copy";
    copy.dataset.shortlinkerCopyValue = url;
    copy.textContent = ShortlinkerAdmin.copy;
    const stats = document.createElement("p");
    const postId = container.closest("[data-shortlinker-post]")?.dataset.shortlinkerPost || "";
    const clicks = document.createElement("span");
    clicks.dataset.shortlinkerClicksLink = "";
    clicks.dataset.postId = postId;
    const clickCount = document.createElement("strong");
    clickCount.className = "shortlinker-click-count";
    clickCount.textContent = "0";
    clicks.append(clickCount, ` ${ShortlinkerAdmin.clicks} · `);
    const statsLink = document.createElement("a");
    statsLink.href = `${ShortlinkerAdmin.analyticsUrl}/${encodeURIComponent(linkId)}`;
    statsLink.target = "_blank";
    statsLink.rel = "noopener";
    statsLink.textContent = `${ShortlinkerAdmin.viewStats} ↗`;
    stats.append(clicks, statsLink);
    row.append(link, copy);
    container.replaceChildren(row, stats);
  };

  document.querySelectorAll("[data-shortlinker-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.shortlinkerConfirm)) event.preventDefault();
    });
  });

  document.querySelectorAll(".shortlinker-post-type-setting").forEach((setting) => {
    const enabled = setting.querySelector("[data-shortlinker-enable-type]");
    const automatic = setting.querySelector("[data-shortlinker-auto-type]");
    if (!enabled || !automatic) return;
    enabled.addEventListener("change", () => {
      automatic.disabled = !enabled.checked;
      if (!enabled.checked) automatic.checked = false;
    });
  });
  document.addEventListener("click", async (event) => {
    const button = event.target.closest(".shortlinker-copy");
    if (!button) return;
    const original = button.textContent;
    try {
      await copyText(button.dataset.shortlinkerCopyValue || "");
      button.textContent = ShortlinkerAdmin.copied;
    } catch (_) {
      button.textContent = ShortlinkerAdmin.copyError;
    }
    window.setTimeout(() => { button.textContent = original; }, 1800);
  });
  document.querySelectorAll(".shortlinker-generate").forEach((button) => {
    button.addEventListener("click", async () => {
      const box = button.closest("[data-shortlinker-post]");
      const replace = button.dataset.replace === "1";
      if (replace && !window.confirm(ShortlinkerAdmin.confirmRegenerate)) return;
      const original = button.textContent;
      button.disabled = true;
      button.textContent = ShortlinkerAdmin.generating;
      const data = new URLSearchParams({ action: "shortlinker_generate", nonce: ShortlinkerAdmin.nonce, postId: box.dataset.shortlinkerPost, replace: replace ? "1" : "" });
      try {
        const response = await fetch(ShortlinkerAdmin.ajaxUrl, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: data });
        const result = await response.json();
        if (!result.success) throw new Error((result.data && result.data.message) || ShortlinkerAdmin.error);
        renderShortlink(box.querySelector(".shortlinker-result"), result.data.url, result.data.id);
        button.dataset.replace = "1";
        button.textContent = ShortlinkerAdmin.regenerate;
        box.querySelector(".shortlinker-message").textContent = "✓";
      } catch (error) {
        box.querySelector(".shortlinker-message").textContent = error.message;
        button.textContent = original;
      } finally { button.disabled = false; }
    });
  });

  const formatNumber = (value) => Number(value || 0).toLocaleString();
  const clickNodes = [...document.querySelectorAll("[data-shortlinker-clicks-link][data-post-id]")];
  if (clickNodes.length) {
    const postIds = [...new Set(clickNodes.map((node) => node.dataset.postId).filter(Boolean))];
    request("shortlinker_click_counts", {
      nonce: ShortlinkerAdmin.statsNonce,
      postIds: JSON.stringify(postIds),
    }).then((data) => {
      clickNodes.forEach((node) => {
        if (!Object.prototype.hasOwnProperty.call(data.clicks || {}, node.dataset.postId)) return;
        const count = node.querySelector(".shortlinker-click-count");
        if (count) count.textContent = formatNumber(data.clicks[node.dataset.postId]);
      });
    }).catch(() => {
      // Keep the locally cached value when the API is temporarily unavailable.
    });
  }

  document.querySelectorAll("[data-shortlinker-stats-summary]").forEach((summary) => {
    const status = summary.querySelector("[data-shortlinker-stats-status]");
    const list = summary.querySelector("[data-shortlinker-top-links]");
    request("shortlinker_stats_summary", { nonce: ShortlinkerAdmin.statsNonce }).then((data) => {
      const globalClicks = summary.querySelector("[data-shortlinker-global-clicks]");
      if (globalClicks) globalClicks.textContent = formatNumber(data.clicks);
      list.replaceChildren();
      (data.topLinks || []).forEach((item) => {
        const row = document.createElement("li");
        const link = document.createElement("a");
        link.href = `https://${item.domain}/${item.slug}`;
        link.target = "_blank";
        link.rel = "noopener";
        link.textContent = `${item.domain}/${item.slug}`;
        const count = document.createElement("strong");
        count.textContent = `${formatNumber(item.clicks)} ${ShortlinkerAdmin.clicks}`;
        row.append(link, count);
        list.appendChild(row);
      });
      status.textContent = (data.topLinks || []).length ? "" : ShortlinkerAdmin.noClickData;
    }).catch((error) => {
      status.textContent = error.message || ShortlinkerAdmin.statsLoadError;
      status.classList.add("shortlinker-editor-error");
    });
  });

  document.querySelectorAll("[data-shortlinker-bulk]").forEach((bulk) => {
    const type = bulk.querySelector("[data-shortlinker-bulk-type]");
    const start = bulk.querySelector("[data-shortlinker-bulk-start]");
    const stop = bulk.querySelector("[data-shortlinker-bulk-stop]");
    const status = bulk.querySelector("[data-shortlinker-bulk-status]");
    const numbers = bulk.querySelector("[data-shortlinker-bulk-numbers]");
    const progress = bulk.querySelector(".shortlinker-bulk-progress");
    const terminal = bulk.querySelector("[data-shortlinker-bulk-log]");
    let running = false;

    const timestamp = () => new Date().toLocaleTimeString();
    const log = (message, state = "info") => {
      const line = document.createElement("div");
      line.className = `is-${state}`;
      line.textContent = `[${timestamp()}] ${message}`;
      terminal.appendChild(line);
      terminal.scrollTop = terminal.scrollHeight;
    };
    const setProgress = (processed, total) => {
      const percentage = total > 0 ? Math.min(100, Math.round((processed / total) * 100)) : 100;
      progress.value = percentage;
      progress.textContent = `${percentage}%`;
      numbers.textContent = `${processed.toLocaleString()} / ${total.toLocaleString()} (${percentage}%)`;
    };
    const bulkRequest = (action, extra = {}) => request(action, {
      nonce: ShortlinkerAdmin.bulkNonce,
      postType: type.value,
      ...extra,
    });
    const refreshCount = async () => {
      status.textContent = ShortlinkerAdmin.bulkCounting;
      start.disabled = true;
      try {
        const counts = await bulkRequest("shortlinker_bulk_status");
        setProgress(counts.linked, counts.published);
        status.textContent = `${counts.missing.toLocaleString()} ${ShortlinkerAdmin.missingLabel} · ${counts.linked.toLocaleString()} ${ShortlinkerAdmin.linkedLabel}`;
        start.disabled = counts.missing === 0;
        return counts;
      } catch (error) {
        status.textContent = error.message;
        log(error.message, "error");
        return null;
      }
    };
    const setRunning = (value) => {
      running = value;
      type.disabled = value;
      start.disabled = value;
      stop.disabled = !value;
    };

    type.addEventListener("change", refreshCount);
    stop.addEventListener("click", () => {
      if (!running) return;
      running = false;
      stop.disabled = true;
      status.textContent = ShortlinkerAdmin.bulkStopping;
      log(ShortlinkerAdmin.bulkStopping, "warning");
    });
    start.addEventListener("click", async () => {
      if (running || !window.confirm(ShortlinkerAdmin.confirmBulk)) return;
      terminal.replaceChildren();
      log(ShortlinkerAdmin.bulkStarting);
      const counts = await refreshCount();
      if (!counts || counts.missing === 0) {
        if (counts) log(ShortlinkerAdmin.bulkNothing, "success");
        return;
      }
      setRunning(true);
      const total = counts.missing;
      let processed = 0;
      let created = 0;
      let failed = 0;
      let cursor = 0;
      setProgress(0, total);
      status.textContent = ShortlinkerAdmin.bulkStarting;
      try {
        while (running) {
          let batch = null;
          let attempts = 0;
          while (running && !batch) {
            try {
              batch = await bulkRequest("shortlinker_bulk_batch", { afterId: String(cursor), limit: "50" });
            } catch (error) {
              attempts += 1;
              if (attempts >= 3) throw error;
              log(`${ShortlinkerAdmin.bulkRetry} (${attempts}/3)`, "warning");
              await new Promise((resolve) => window.setTimeout(resolve, attempts * 1000));
            }
          }
          if (!batch || batch.finished) break;
          batch.items.forEach((item) => {
            if (item.status === "success") log(`[OK] #${item.id} ${item.title} → ${item.url}`, "success");
            else log(`[ERROR] #${item.id} ${item.title} — ${item.message}`, "error");
          });
          processed += Number(batch.processed || 0);
          created += Number(batch.created || 0);
          failed += Number(batch.failed || 0);
          cursor = Number(batch.cursor || cursor);
          setProgress(processed, total);
          status.textContent = `${created.toLocaleString()} ${ShortlinkerAdmin.createdLabel} · ${failed.toLocaleString()} ${ShortlinkerAdmin.failedLabel}`;
          await new Promise((resolve) => window.setTimeout(resolve, 100));
        }
        if (running) {
          setProgress(total, total);
          status.textContent = `${ShortlinkerAdmin.bulkComplete} ${created.toLocaleString()} ${ShortlinkerAdmin.createdLabel} · ${failed.toLocaleString()} ${ShortlinkerAdmin.failedLabel}`;
          log(status.textContent, failed ? "warning" : "success");
        } else {
          status.textContent = `${ShortlinkerAdmin.bulkStopped} ${created.toLocaleString()} ${ShortlinkerAdmin.createdLabel} · ${failed.toLocaleString()} ${ShortlinkerAdmin.failedLabel}`;
          log(status.textContent, "warning");
        }
      } catch (error) {
        status.textContent = error.message;
        log(error.message, "error");
      } finally {
        setRunning(false);
        const latest = await refreshCount();
        if (latest && latest.missing > 0 && failed > 0) log(`${latest.missing.toLocaleString()} ${ShortlinkerAdmin.remainingLabel}`, "warning");
      }
    });
    refreshCount();
  });
})();
